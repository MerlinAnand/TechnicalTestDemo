package Util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.concurrent.TimeUnit;
/**
 * Created by Merlin on 31/07/2019.
 * This is a base class which is used for initialization and tear down
 */
public class TestBase {

    public static WebDriver driver;
    public static DataProviders.ConfigFileReader configFileReader;

/*
   Initialization of browser drivers, URLS
 */
     public static void initialization(){
         configFileReader= new DataProviders.ConfigFileReader();
         String browserName = configFileReader.getBrowser();
        //Invoke Chrome Browser
        if(browserName.equals("chrome")){
            System.setProperty("webdriver.chrome.driver",configFileReader.getDriverPath());
            driver = new ChromeDriver();
        }
        else if(browserName.equals("firefox")){
            System.setProperty("webdriver.gecko.driver",configFileReader.getDriverPath());
            driver = new FirefoxDriver();
        }
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT,TimeUnit.SECONDS);
        driver.get(configFileReader.getApplicationUrl());
    }

 /*
   Tear down of the application
  */
    public static void closeApp(){
         driver.close();
    }


}




