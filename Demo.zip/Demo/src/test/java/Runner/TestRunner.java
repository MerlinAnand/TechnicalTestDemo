package Runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "C://Merlin//Demo//src//test//java//Features//search.feature",
        glue={"stepDefinitions"},
        plugin = {"pretty","html:target/cucumber-reports"},
        monochrome = true,
        dryRun = false

        )
public class TestRunner {
}
