package stepDefinitions;
import Pages.SearchPage;
import io.cucumber.java.en.Then;
/**
 * Created by Merlin on 31/07/2019.
 */
import org.openqa.selenium.WebDriver;

public class SearchPageSteps {

    WebDriver driver;
    SearchPage searchPage= new SearchPage();

    @Then("user selects redplan")
    public void userSelectsRedplan() throws InterruptedException {
        searchPage.redDeal();
    }
}
