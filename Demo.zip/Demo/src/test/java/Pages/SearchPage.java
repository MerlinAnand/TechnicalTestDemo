package Pages;
import Util.TestBase;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.concurrent.TimeUnit;

/**
 * Created by Merlin on 31/07/2019.
 */
public class SearchPage extends TestBase {

    //Creating the JavascriptExecutor interface object by Type casting
    JavascriptExecutor js = (JavascriptExecutor)driver;

    @FindBy(xpath="//*[@id=\"e2e-itinerary-0\"]/div/div[2]/div/upsell-itinerary-fares/upsell-fare-cell[1]/div/label")
    WebElement lnkAmt;

    @FindBy(xpath="//*[@id=\"upsell-container-bound0\"]/div/upsell-itinerary-avail[1]/div/div[2]/div/div/div[2]/div[4]/button/span")
    WebElement btnAddTrip;

    @FindBy(xpath="//*[@id=\"btn-continue\"]")
    WebElement btnContinue;

    @FindBy(xpath="//*[@id=\"btn-accept\"]/span")
    WebElement btnAccept;

    public SearchPage(){
        PageFactory.initElements(driver,this);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }

    public String VerifySearchPageTitle(){
        return driver.getTitle();
    }
/*
    This method used to choose Reddeal and procees to Options Page and returns the Options Page
 */
    public OptionsPage redDeal() throws InterruptedException {
        if (lnkAmt.isDisplayed()) {
            // Click the Red Deal Link
            lnkAmt.click();
            //Click the Add Trip Button
            btnAddTrip.click();
            //Click the Continue Button
            btnContinue.click();
            //Click the Continue Button
            btnContinue.click();
            //Click the Accept Button
            btnAccept.click();
            return new OptionsPage();
        }
        return new OptionsPage();
    }


}
