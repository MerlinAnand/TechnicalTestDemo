package Pages;
import Util.GetCurrentDate;
import Util.TestBase;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
/**
 * Created by Merlin on 31/07/2019.
 */
public class HomePage extends TestBase {

    //Creating the JavascriptExecutor interface object by Type casting
    JavascriptExecutor js = (JavascriptExecutor) driver;

    // Page Factory - OR
    @FindBy(xpath = "//input[@id='typeahead-input-from']")
    WebElement txtfrom;

    @FindBy(xpath = "//input[@id='typeahead-input-to']")
    WebElement txtto;

    @FindBy(xpath = "//input[@id='datepicker-input-departureDate']")
    WebElement txtdepart;

    @FindBy(xpath = "//td[@aria-label='Sunday, the twenty fifth of August 2019']")
    WebElement txtdate;

    @FindBy(xpath = "//div[@class='only-show-for-tablet-desktop']/div[2]/div/fieldset/div/div/input[@aria-label='One way']")
    WebElement rdtrip;

    @FindBy(xpath = "//div[@class='qfa1-submit-button__container-right widget-form__group-container size-big']")
    WebElement btnSearch;

    @FindBy(xpath = "//*[@id=\"collapsibleCard0\"]/div[2]/cart-collapsible-card-footer/cart-flights-subtotal/div/div[1]/div[2]/div/cart-subtotal-row/span[1]")
    WebElement txtSubtotal;


    public HomePage() {
        PageFactory.initElements(driver, this);
    }

    /*

     */
    public SearchPage search(String source, String des) throws InterruptedException {
        String result = driver.toString();
        if (!result.isEmpty()) {
            txtfrom.sendKeys(source);
            txtto.click();
            txtto.sendKeys(des);
            txtto.sendKeys(Keys.ENTER);
            //Perform Click on Oneway  button using JavascriptExecutor
            js.executeScript("arguments[0].click();", rdtrip);
            txtdepart.click();
            txtdate.click();
            btnSearch.click();
            String newdate = GetCurrentDate.getSdf();
            System.out.println("New Date : ->" + newdate);
            Assert.assertEquals("$0", txtSubtotal.getText());
        } else {
            Assert.assertFalse("Browser not launched", result.isEmpty());
        }
        return new SearchPage();
    }
}


